import React from 'react';
import { ArrowDown } from 'lucide-react';

const HeroSection: React.FC = () => {
  return (
    <div className="relative min-h-screen flex items-center bg-gradient-to-b from-[#f9f9ff] to-white pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-24">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="text-center md:text-left">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight mb-6">
              <span className="block">Le montage simplifié pour</span>
              <span className="text-[#6236FF]">créateurs de contenu courts</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-lg mx-auto md:mx-0">
              Transforme tes vidéos en contenu viral en quelques clics. CaptionFlow t'aide à monter tes Reels, Shorts & TikToks <strong>en un temps record</strong>, sans logiciel compliqué.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center md:justify-start gap-4">
              <a 
                href="#beta" 
                className="px-8 py-3 rounded-lg bg-[#6236FF] text-white font-medium hover:bg-[#5026DF] transition-colors shadow-lg hover:shadow-xl hover:shadow-[#6236FF]/20 w-full sm:w-auto text-center"
              >
                Rejoindre la bêta gratuite
              </a>
              <a 
                href="#features" 
                className="flex items-center justify-center gap-2 px-6 py-3 rounded-lg bg-white text-gray-800 border border-gray-200 font-medium hover:bg-gray-50 transition-colors w-full sm:w-auto text-center"
              >
                Découvrir <ArrowDown size={16} />
              </a>
            </div>
          </div>
          <div className="relative flex justify-center items-center">
            <div className="w-full max-w-md h-[600px] bg-gray-900 rounded-3xl overflow-hidden shadow-2xl relative">
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent"></div>
              <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                <div className="bg-black/70 backdrop-blur-sm p-4 rounded-xl mb-4">
                  <p className="text-lg font-bold">Comment créer du contenu viral facilement</p>
                </div>
                <div className="flex justify-between items-center">
                  <div className="flex space-x-2">
                    <button className="w-10 h-10 rounded-full bg-white flex items-center justify-center">
                      <span className="sr-only">Play</span>
                      <div className="w-0 h-0 border-t-[7px] border-t-transparent border-l-[12px] border-l-black border-b-[7px] border-b-transparent ml-1"></div>
                    </button>
                    <div className="w-full bg-gray-500/50 h-2 rounded-full self-center">
                      <div className="bg-white h-full w-1/3 rounded-full"></div>
                    </div>
                  </div>
                  <span className="text-sm">0:45</span>
                </div>
              </div>
            </div>
            {/* Decorative elements */}
            <div className="absolute -top-10 -right-10 w-20 h-20 bg-[#6236FF]/20 rounded-full blur-xl"></div>
            <div className="absolute -bottom-5 -left-5 w-16 h-16 bg-[#6236FF]/30 rounded-full blur-lg"></div>
          </div>
        </div>
      </div>
      <div className="absolute bottom-10 left-0 right-0 flex justify-center animate-bounce">
        <a href="#features" className="text-gray-400 hover:text-gray-600">
          <ArrowDown size={24} />
        </a>
      </div>
    </div>
  );
};

export default HeroSection;