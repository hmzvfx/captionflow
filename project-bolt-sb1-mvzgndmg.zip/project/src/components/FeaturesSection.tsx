import React from 'react';
import { Video, Scissors, Zap, Volume2, Type } from 'lucide-react';

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  color: string;
}

const FeatureCard: React.FC<FeatureCardProps> = ({ icon, title, description, color }) => {
  return (
    <div className="bg-white rounded-2xl shadow-lg p-6 transition-all hover:shadow-xl hover:-translate-y-1 duration-300">
      <div className={`w-14 h-14 flex items-center justify-center rounded-xl mb-4 ${color}`}>
        {icon}
      </div>
      <h3 className="text-xl font-bold mb-3">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
};

const FeaturesSection: React.FC = () => {
  const features = [
    {
      icon: <Video className="text-white w-6 h-6" />,
      title: "Interface intuitive",
      description: "Timeline simple, drag-and-drop minimaliste, vue optimisée pour formats verticaux.",
      color: "bg-blue-500"
    },
    {
      icon: <Type className="text-white w-6 h-6" />,
      title: "Sous-titres automatiques",
      description: "Génération de sous-titres avec plusieurs styles (Hormozi, clean, pop, punchy…)",
      color: "bg-purple-500"
    },
    {
      icon: <Scissors className="text-white w-6 h-6" />,
      title: "Cuts automatiques",
      description: "Suppression automatique des blancs, coupes nettes entre prises de parole.",
      color: "bg-pink-500"
    },
    {
      icon: <Zap className="text-white w-6 h-6" />,
      title: "Transitions dynamiques",
      description: "Ajout simple de transitions impactantes (glitch, zoom, swipe, jump-cut…)",
      color: "bg-amber-500"
    },
    {
      icon: <Volume2 className="text-white w-6 h-6" />,
      title: "SFX intégrés",
      description: "Petite banque de sons pour dynamiser les cuts (pops, whoosh, impact, etc.)",
      color: "bg-green-500"
    }
  ];

  return (
    <div id="features" className="bg-gray-50 py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Fonctionnalités Principales</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Des outils simples mais puissants pour transformer tes vidéos en contenu engageant.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <FeatureCard 
              key={index}
              icon={feature.icon}
              title={feature.title}
              description={feature.description}
              color={feature.color}
            />
          ))}
        </div>

        <div className="mt-20">
          <div className="bg-white rounded-3xl shadow-xl overflow-hidden">
            <div className="p-8 md:p-12">
              <h3 className="text-2xl font-bold mb-6 text-center">Comment ça marche ?</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="text-center">
                  <div className="w-16 h-16 bg-[#6236FF] rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="text-white font-bold text-xl">1</span>
                  </div>
                  <h4 className="font-bold mb-2">Importe ta vidéo</h4>
                  <p className="text-gray-600">Télécharge ta vidéo brute depuis ton téléphone ou ton ordinateur</p>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 bg-[#6236FF] rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="text-white font-bold text-xl">2</span>
                  </div>
                  <h4 className="font-bold mb-2">Personnalise</h4>
                  <p className="text-gray-600">Choisis ton style de sous-titres, ajoute des coupes et transitions</p>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 bg-[#6236FF] rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="text-white font-bold text-xl">3</span>
                  </div>
                  <h4 className="font-bold mb-2">Exporte</h4>
                  <p className="text-gray-600">Télécharge ta vidéo prête à être publiée sur les réseaux sociaux</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FeaturesSection;