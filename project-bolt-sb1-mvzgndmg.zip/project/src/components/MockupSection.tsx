import React from 'react';

const MockupSection: React.FC = () => {
  return (
    <div className="py-20 bg-gradient-to-b from-white to-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Aperçu visuel de l'outil</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Une interface intuitive conçue pour un montage rapide et efficace
          </p>
        </div>

        <div className="relative mx-auto max-w-5xl">
          {/* Decorative elements */}
          <div className="absolute -top-10 -left-10 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl"></div>
          <div className="absolute -bottom-20 -right-10 w-72 h-72 bg-purple-500/10 rounded-full blur-3xl"></div>
          
          <div className="relative bg-gray-900 rounded-3xl shadow-2xl overflow-hidden">
            {/* Top Bar - Similar to video editing software */}
            <div className="bg-gray-800 px-6 py-3 flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 rounded-full bg-red-500"></div>
                <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                <div className="w-3 h-3 rounded-full bg-green-500"></div>
              </div>
              <div className="text-white font-medium">CaptionFlow - Interface de montage</div>
              <div className="w-16"></div> {/* For layout balance */}
            </div>
            
            {/* Main content area */}
            <div className="p-6 grid grid-cols-12 gap-4 h-[500px]">
              {/* Video preview pane */}
              <div className="col-span-8 bg-black rounded-xl relative">
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-[240px] h-[426px] bg-gray-800 rounded-xl overflow-hidden relative">
                    {/* Simulated phone content */}
                    <div className="absolute bottom-0 left-0 right-0 p-4">
                      <div className="bg-black/60 backdrop-blur-sm text-white p-2 rounded-lg mb-4 font-medium text-center">
                        "Comment j'ai gagné 10K abonnés en 30 jours"
                      </div>
                      <div className="h-1 bg-white/30 rounded-full">
                        <div className="h-1 bg-[#6236FF] rounded-full w-1/2"></div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="absolute bottom-4 left-4 right-4 flex justify-between text-white">
                  <div className="flex space-x-3">
                    <button className="w-8 h-8 rounded-full bg-gray-700 flex items-center justify-center">
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                      </svg>
                    </button>
                    <button className="w-8 h-8 rounded-full bg-[#6236FF] flex items-center justify-center">
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 9v6m4-6v6m7-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </button>
                    <button className="w-8 h-8 rounded-full bg-gray-700 flex items-center justify-center">
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                      </svg>
                    </button>
                  </div>
                  <div className="text-sm">00:15 / 00:45</div>
                </div>
              </div>
              
              {/* Right sidebar for tools */}
              <div className="col-span-4 bg-gray-800 rounded-xl p-4 flex flex-col">
                <h3 className="text-white font-medium mb-4">Style de sous-titres</h3>
                <div className="grid grid-cols-2 gap-2 mb-4">
                  <div className="bg-[#6236FF] text-white p-2 rounded-lg text-xs text-center">Hormozi</div>
                  <div className="bg-gray-700 text-white p-2 rounded-lg text-xs text-center">Clean</div>
                  <div className="bg-gray-700 text-white p-2 rounded-lg text-xs text-center">Pop</div>
                  <div className="bg-gray-700 text-white p-2 rounded-lg text-xs text-center">Punchy</div>
                </div>
                
                <h3 className="text-white font-medium mt-2 mb-3">Transitions</h3>
                <div className="grid grid-cols-3 gap-2 mb-4">
                  <div className="bg-[#6236FF] text-white p-2 rounded-lg text-xs text-center">Glitch</div>
                  <div className="bg-gray-700 text-white p-2 rounded-lg text-xs text-center">Zoom</div>
                  <div className="bg-gray-700 text-white p-2 rounded-lg text-xs text-center">Swipe</div>
                </div>
                
                <h3 className="text-white font-medium mt-2 mb-3">Son</h3>
                <div className="bg-gray-700 rounded-lg p-2 mb-4">
                  <div className="flex justify-between items-center">
                    <span className="text-white text-xs">Volume</span>
                    <span className="text-white text-xs">100%</span>
                  </div>
                  <div className="h-1 bg-gray-600 rounded-full mt-2">
                    <div className="h-1 bg-[#6236FF] rounded-full w-full"></div>
                  </div>
                </div>
                
                <div className="mt-auto">
                  <button className="w-full bg-[#6236FF] text-white py-2 rounded-lg font-medium">
                    Exporter la vidéo
                  </button>
                </div>
              </div>
              
              {/* Timeline at bottom */}
              <div className="col-span-12 bg-gray-800 rounded-xl p-4">
                <div className="flex justify-between text-white text-xs mb-2">
                  <span>Timeline</span>
                  <span>00:45</span>
                </div>
                <div className="bg-gray-700 h-12 rounded-lg relative">
                  {/* Video segments */}
                  <div className="absolute left-0 top-0 bottom-0 w-1/4 bg-blue-500/30 rounded-l-lg"></div>
                  <div className="absolute left-[25%] top-0 bottom-0 w-1/4 bg-purple-500/30"></div>
                  <div className="absolute left-[50%] top-0 bottom-0 w-1/4 bg-pink-500/30"></div>
                  <div className="absolute left-[75%] top-0 bottom-0 w-1/4 bg-amber-500/30 rounded-r-lg"></div>
                  
                  {/* Playhead */}
                  <div className="absolute left-1/2 top-0 bottom-0 w-0.5 bg-white z-10">
                    <div className="w-3 h-3 bg-white rounded-full -mt-1 -ml-1.5"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="mt-10 text-center">
            <button className="inline-flex items-center justify-center gap-2 px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-[#6236FF] hover:bg-[#5026DF] shadow-lg hover:shadow-xl hover:shadow-[#6236FF]/20 transition-all">
              Essayer la démo
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MockupSection;