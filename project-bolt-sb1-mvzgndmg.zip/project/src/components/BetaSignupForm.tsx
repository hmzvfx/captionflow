import React, { useState } from 'react';
import { Send } from 'lucide-react';

const BetaSignupForm: React.FC = () => {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email) {
      setError('Veuillez entrer votre email');
      return;
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setError('Veuillez entrer un email valide');
      return;
    }

    // In a real app, you would send this to your backend
    console.log('Email submitted:', email);
    
    // Show success message
    setSubmitted(true);
    setError('');
  };

  return (
    <div id="beta" className="bg-[#f9f9ff] py-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-3xl shadow-xl overflow-hidden">
          <div className="grid grid-cols-1 md:grid-cols-2">
            <div className="p-8 md:p-12 bg-[#6236FF]">
              <div className="h-full flex flex-col justify-center">
                <h3 className="text-2xl md:text-3xl font-bold text-white mb-4">Rejoins la bêta gratuite</h3>
                <p className="text-white/80 mb-6">
                  Sois parmi les premiers à tester CaptionFlow et à transformer tes vidéos en contenu viral.
                </p>
                <div className="bg-white/10 rounded-lg p-4 backdrop-blur-sm">
                  <p className="text-white text-sm">
                    "CaptionFlow est conçu par un créateur pour les créateurs. Si tu veux monter vite, bien, et sans prise de tête : CaptionFlow est fait pour toi."
                  </p>
                  <p className="text-white/80 text-sm mt-2">- Hamza @clipo.media</p>
                </div>
              </div>
            </div>
            
            <div className="p-8 md:p-12">
              {!submitted ? (
                <>
                  <h4 className="text-xl font-bold mb-6">Laisse ton e-mail pour être prévenu dès la sortie</h4>
                  <form onSubmit={handleSubmit}>
                    <div className="mb-4">
                      <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                        Adresse e-mail
                      </label>
                      <input
                        type="email"
                        id="email"
                        placeholder="ton@email.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className={`w-full px-4 py-3 rounded-lg border ${error ? 'border-red-500' : 'border-gray-300'} focus:outline-none focus:ring-2 focus:ring-[#6236FF] focus:border-transparent`}
                      />
                      {error && <p className="mt-1 text-sm text-red-600">{error}</p>}
                    </div>
                    
                    <button
                      type="submit"
                      className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-[#6236FF] text-white rounded-lg font-medium hover:bg-[#5026DF] transition-colors shadow-lg hover:shadow-xl hover:shadow-[#6236FF]/20"
                    >
                      M'inscrire à la bêta <Send size={16} />
                    </button>
                  </form>
                  
                  <p className="mt-4 text-sm text-gray-500">
                    En vous inscrivant, vous acceptez de recevoir des emails concernant CaptionFlow.
                    Vous pourrez vous désinscrire à tout moment.
                  </p>
                </>
              ) : (
                <div className="text-center py-8">
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Check className="h-8 w-8 text-green-600" />
                  </div>
                  <h4 className="text-xl font-bold mb-2">Merci pour ton inscription !</h4>
                  <p className="text-gray-600">
                    Nous te contacterons dès que la bêta sera disponible. 
                    En attendant, n'hésite pas à nous suivre sur les réseaux sociaux.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BetaSignupForm;

import { Check } from 'lucide-react';