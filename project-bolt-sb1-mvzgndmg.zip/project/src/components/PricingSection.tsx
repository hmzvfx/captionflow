import React from 'react';
import { Check } from 'lucide-react';

interface PricingTierProps {
  name: string;
  price: string;
  description: string;
  features: string[];
  color: string;
  popular?: boolean;
  buttonText?: string;
}

const PricingTier: React.FC<PricingTierProps> = ({ 
  name, 
  price, 
  description, 
  features, 
  color,
  popular = false,
  buttonText = "Commencer"
}) => {
  return (
    <div className={`bg-white rounded-2xl shadow-lg overflow-hidden transition-all duration-300 hover:shadow-xl relative ${popular ? 'border-2 border-[#6236FF] transform md:-translate-y-4' : ''}`}>
      {popular && (
        <div className="absolute top-0 left-0 right-0 bg-[#6236FF] text-white text-center py-1 text-sm font-medium">
          Recommandé
        </div>
      )}
      <div className="p-6 md:p-8">
        <div className={`inline-block text-sm font-semibold px-3 py-1 rounded-full mb-4 ${color}`}>
          {name}
        </div>
        <div className="flex items-end gap-2 mb-4">
          <span className="text-4xl font-bold">{price}</span>
          {price !== "Gratuit" && <span className="text-gray-500">/mois</span>}
        </div>
        <p className="text-gray-600 mb-6">{description}</p>
        
        <ul className="space-y-3 mb-8">
          {features.map((feature, index) => (
            <li key={index} className="flex items-start">
              <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
              <span className="text-gray-700">{feature}</span>
            </li>
          ))}
        </ul>
        
        <button className={`w-full py-3 rounded-lg font-medium transition-colors ${
          popular 
            ? 'bg-[#6236FF] text-white hover:bg-[#5026DF]' 
            : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
        }`}>
          {buttonText}
        </button>
      </div>
    </div>
  );
};

const PricingSection: React.FC = () => {
  const pricingTiers = [
    {
      name: "Starter",
      price: "Gratuit",
      description: "Parfait pour essayer l'outil et créer tes premiers contenus.",
      color: "bg-green-100 text-green-800",
      features: [
        "4 vidéos par mois",
        "Templates de base",
        "Sous-titres automatiques",
        "Cuts automatiques",
        "Filigrane visible"
      ],
      buttonText: "Commencer gratuitement"
    },
    {
      name: "Creator",
      price: "7€",
      description: "Idéal pour les créateurs réguliers qui veulent plus d'options.",
      color: "bg-amber-100 text-amber-800",
      popular: true,
      features: [
        "16 vidéos par mois",
        "Plus de styles de sous-titres",
        "Cuts + transitions",
        "Sans filigrane",
        "Support prioritaire"
      ]
    },
    {
      name: "Pro",
      price: "20€",
      description: "Pour les créateurs professionnels avec des besoins avancés.",
      color: "bg-red-100 text-red-800",
      features: [
        "Vidéos illimitées",
        "Templates premium",
        "Transitions avancées",
        "Banque de SFX intégrée",
        "Export en haute qualité"
      ]
    }
  ];

  return (
    <div id="pricing" className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Une stratégie Freemium</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Commence gratuitement et passe à un forfait payant quand tu es prêt.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {pricingTiers.map((tier, index) => (
            <PricingTier 
              key={index}
              name={tier.name}
              price={tier.price}
              description={tier.description}
              features={tier.features}
              color={tier.color}
              popular={tier.popular}
              buttonText={tier.buttonText}
            />
          ))}
        </div>

        <div className="mt-12 text-center">
          <p className="text-gray-500">
            Tous les prix sont en euros (€) · Facturation mensuelle · Annulez à tout moment
          </p>
        </div>
      </div>
    </div>
  );
};

export default PricingSection;