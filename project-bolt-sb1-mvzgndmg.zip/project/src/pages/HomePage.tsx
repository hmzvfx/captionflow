import React from 'react';
import Navbar from '../components/Navbar';
import HeroSection from '../components/HeroSection';
import FeaturesSection from '../components/FeaturesSection';
import MockupSection from '../components/MockupSection';
import PricingSection from '../components/PricingSection';
import BetaSignupForm from '../components/BetaSignupForm';
import Footer from '../components/Footer';

const HomePage: React.FC = () => {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <HeroSection />
      <FeaturesSection />
      <MockupSection />
      <PricingSection />
      <BetaSignupForm />
      <Footer />
    </div>
  );
};

export default HomePage;