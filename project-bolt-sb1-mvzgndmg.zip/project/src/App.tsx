import React from 'react';
import HomePage from './pages/HomePage';

function App() {
  // Update the page title
  React.useEffect(() => {
    document.title = "CaptionFlow — Le montage simplifié pour créateurs de contenu";
  }, []);

  return <HomePage />;
}

export default App;